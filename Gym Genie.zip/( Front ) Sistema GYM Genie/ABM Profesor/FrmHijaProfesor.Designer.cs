﻿namespace __Front___Sistema_GYM_Genie
{
    partial class FrmHijaProfesor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHijaProfesor));
            LblTituloProfesor = new Label();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            BtnModProfesor = new Button();
            BtnBajaProfesor = new Button();
            BtnAltaProfesor = new Button();
            panel4 = new Panel();
            panel3 = new Panel();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // LblTituloProfesor
            // 
            LblTituloProfesor.Anchor = AnchorStyles.Top;
            LblTituloProfesor.BorderStyle = BorderStyle.Fixed3D;
            LblTituloProfesor.Font = new Font("Impact", 34F, FontStyle.Italic, GraphicsUnit.Point);
            LblTituloProfesor.ForeColor = Color.FromArgb(0, 205, 255);
            LblTituloProfesor.Location = new Point(450, 29);
            LblTituloProfesor.Name = "LblTituloProfesor";
            LblTituloProfesor.Size = new Size(223, 66);
            LblTituloProfesor.TabIndex = 12;
            LblTituloProfesor.Text = "PROFESOR";
            LblTituloProfesor.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            pictureBox3.Anchor = AnchorStyles.None;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(324, 209);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Anchor = AnchorStyles.None;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(324, 209);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(BtnModProfesor);
            panel1.Controls.Add(BtnBajaProfesor);
            panel1.Controls.Add(BtnAltaProfesor);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1116, 738);
            panel1.TabIndex = 11;
            // 
            // BtnModProfesor
            // 
            BtnModProfesor.Anchor = AnchorStyles.None;
            BtnModProfesor.BackColor = Color.FromArgb(20, 20, 20);
            BtnModProfesor.FlatAppearance.BorderColor = Color.Gray;
            BtnModProfesor.FlatAppearance.MouseDownBackColor = Color.FromArgb(7, 29, 49);
            BtnModProfesor.FlatAppearance.MouseOverBackColor = Color.Gray;
            BtnModProfesor.Font = new Font("Impact", 30F, FontStyle.Italic, GraphicsUnit.Point);
            BtnModProfesor.ForeColor = Color.FromArgb(0, 205, 255);
            BtnModProfesor.Location = new Point(773, 414);
            BtnModProfesor.Name = "BtnModProfesor";
            BtnModProfesor.Size = new Size(290, 66);
            BtnModProfesor.TabIndex = 8;
            BtnModProfesor.Text = "MODIFICACIÓN";
            BtnModProfesor.UseVisualStyleBackColor = false;
            // 
            // BtnBajaProfesor
            // 
            BtnBajaProfesor.Anchor = AnchorStyles.None;
            BtnBajaProfesor.BackColor = Color.FromArgb(20, 20, 20);
            BtnBajaProfesor.FlatAppearance.BorderColor = Color.Gray;
            BtnBajaProfesor.FlatAppearance.MouseDownBackColor = Color.FromArgb(7, 29, 49);
            BtnBajaProfesor.FlatAppearance.MouseOverBackColor = Color.Gray;
            BtnBajaProfesor.Font = new Font("Impact", 30F, FontStyle.Italic, GraphicsUnit.Point);
            BtnBajaProfesor.ForeColor = Color.FromArgb(0, 205, 255);
            BtnBajaProfesor.Location = new Point(417, 414);
            BtnBajaProfesor.Name = "BtnBajaProfesor";
            BtnBajaProfesor.Size = new Size(290, 66);
            BtnBajaProfesor.TabIndex = 7;
            BtnBajaProfesor.Text = "BAJA";
            BtnBajaProfesor.UseVisualStyleBackColor = false;
            // 
            // BtnAltaProfesor
            // 
            BtnAltaProfesor.Anchor = AnchorStyles.None;
            BtnAltaProfesor.BackColor = Color.FromArgb(20, 20, 20);
            BtnAltaProfesor.FlatAppearance.BorderColor = Color.Gray;
            BtnAltaProfesor.FlatAppearance.MouseDownBackColor = Color.FromArgb(7, 29, 49);
            BtnAltaProfesor.FlatAppearance.MouseOverBackColor = Color.Gray;
            BtnAltaProfesor.Font = new Font("Impact", 30F, FontStyle.Italic, GraphicsUnit.Point);
            BtnAltaProfesor.ForeColor = Color.FromArgb(0, 205, 255);
            BtnAltaProfesor.Location = new Point(63, 414);
            BtnAltaProfesor.Name = "BtnAltaProfesor";
            BtnAltaProfesor.Size = new Size(290, 66);
            BtnAltaProfesor.TabIndex = 6;
            BtnAltaProfesor.Text = "ALTA";
            BtnAltaProfesor.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.FromArgb(0, 205, 255);
            panel4.Controls.Add(pictureBox3);
            panel4.Location = new Point(757, 189);
            panel4.Name = "panel4";
            panel4.Size = new Size(324, 307);
            panel4.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.FromArgb(0, 205, 255);
            panel3.Controls.Add(pictureBox2);
            panel3.Location = new Point(401, 189);
            panel3.Name = "panel3";
            panel3.Size = new Size(324, 307);
            panel3.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.FromArgb(0, 205, 255);
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(46, 189);
            panel2.Name = "panel2";
            panel2.Size = new Size(324, 307);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(324, 209);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // FrmHijaProfesor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(20, 20, 20);
            ClientSize = new Size(1116, 738);
            Controls.Add(LblTituloProfesor);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FrmHijaProfesor";
            Text = "FrmHijaProfesor";
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label LblTituloProfesor;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Button BtnModProfesor;
        private Button BtnBajaProfesor;
        private Button BtnAltaProfesor;
    }
}