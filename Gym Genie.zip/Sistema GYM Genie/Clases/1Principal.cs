﻿using Microsoft.EntityFrameworkCore;
using Sistema_GYM_Genie.DBConection;

namespace Sistema_GYM_Genie.Clases
{
    public class Principal
    {
        Appdbcontext context = new Appdbcontext();
    }
}