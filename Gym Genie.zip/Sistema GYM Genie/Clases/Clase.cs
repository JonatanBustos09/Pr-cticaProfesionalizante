﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_GYM_Genie.Clases
{
    public class Clase
    {
        public int ClaseId { get; set; }
        public string? TipoClase { get; set; }
        public string? NombreClase { get; set; }
        public string? Equipamiento { get; set; }
    }
}
