﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_GYM_Genie.Clases
{
    public class Reserva
    {
        public int ReservaId { get; set; }
        public DateTime DiaReserva { get; set; }
        public DateTime HoraReserva { get; set; }
    }
}
